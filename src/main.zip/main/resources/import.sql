INSERT INTO tarefa (titulo, descricao, prazo, status) VALUES
('Estudar Java', 'Ler Effective Java', TO_TIMESTAMP('2025-05-10 18:00:00', 'YYYY-MM-DD HH24:MI:SS'), 'PENDENTE');

INSERT INTO tarefa (titulo, descricao, prazo, status) VALUES
('Reunião Sprint', 'Daily às 10h', TO_TIMESTAMP('2025-04-04 10:00:00', 'YYYY-MM-DD HH24:MI:SS'), 'EM_ANDAMENTO');