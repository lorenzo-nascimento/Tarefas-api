package br.lorenzo.tarefas_api.model.enums;

public enum StatusTarefa {
    PENDENTE,     // Não iniciada
    EM_ANDAMENTO,
    CONCLUIDA,
    CANCELADA

}
